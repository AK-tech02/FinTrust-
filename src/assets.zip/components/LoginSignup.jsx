import { useState } from 'react';
import { useLoan } from '../context/LoanContext';
import './LoginSignup.css';

const LoginSignup = () => {
    const { login, signup } = useLoan();
    const [isLogin, setIsLogin] = useState(true);
    const [signupStep, setSignupStep] = useState(1); // 1: Details, 2: OTP, 3: Aadhaar
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Form fields
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [rememberMe, setRememberMe] = useState(false);
    const [otp, setOtp] = useState('');
    const [aadhaar, setAadhaar] = useState('');
    const [photoFile, setPhotoFile] = useState(null);

    // Safety check
    if (!login || !signup) {
        return <div style={{ padding: '20px', color: 'white' }}>Loading authentication...</div>;
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);

        if (isLogin) {
            setLoading(true);
            try {
                await login(email, password);
            } catch (err) {
                console.error('Auth error:', err);
                let errorMessage = err.message || 'An error occurred';
                if (errorMessage.includes('Invalid login credentials') || errorMessage.includes('auth/invalid-credential')) {
                    errorMessage = 'Invalid email or password. Please try again, or create an account if you don\'t have one.';
                } else if (errorMessage.includes('auth/email-already-in-use') || errorMessage.includes('User already registered')) {
                    errorMessage = 'This email is already registered. Please sign in instead.';
                    setIsLogin(true);
                } else if (errorMessage.includes('auth/weak-password')) {
                    errorMessage = 'Password should be at least 6 characters.';
                }
                setError(errorMessage);
            } finally {
                setLoading(false);
            }
        } else {
            // Sign Up Multi-Step Logic
            if (signupStep === 1) {
                if (!name || !email || !phone || !password || !photoFile) {
                    setError('Please fill in all fields and upload a passport size photo.');
                    return;
                }
                if (password.length < 6) {
                    setError('Password should be at least 6 characters.');
                    return;
                }
                // Move to OTP Step
                setSignupStep(2);
                setError('OTP sent! For this demo, please enter any 6-digit number (e.g., 123456).');
            } else if (signupStep === 2) {
                if (otp.length !== 6 || !/^\d+$/.test(otp)) {
                    setError('Please enter a valid 6-digit OTP.');
                    return;
                }
                // Move to Aadhaar Step
                setSignupStep(3);
                setError(null);
            } else if (signupStep === 3) {
                if (aadhaar.length !== 12 || !/^\d+$/.test(aadhaar)) {
                    setError('Please enter a valid 12-digit Aadhaar number.');
                    return;
                }

                setLoading(true);
                try {
                    await signup(email, password, name, phone, aadhaar, photoFile);
                } catch (err) {
                    console.error('Auth error:', err);
                    let errorMessage = err.message || 'An error occurred';
                    if (errorMessage.includes('auth/email-already-in-use')) {
                        errorMessage = 'This email is already registered. Please sign in instead.';
                        setIsLogin(true);
                        setSignupStep(1);
                    }
                    setError(errorMessage);
                } finally {
                    setLoading(false);
                }
            }
        }
    };

    const handleGoogleSignIn = () => {
        alert('Google sign-in (Demo)');
    };

    return (
        <div className="login-page">
            {/* Left Side - Welcome Section */}
            <div className="welcome-section">
                <div className="welcome-content">
                    <div className="logo">
                        <div className="logo-icon">💎</div>
                        <div className="logo-text">Fintrust</div>
                    </div>

                    <h1 className="welcome-heading">
                        Welcome to Your<br />
                        Financial Dashboard
                    </h1>

                    <p className="welcome-description">
                        Track your informal loans securely. Build trust with your contacts and manage your money transparently.
                    </p>

                    <div className="feature-cards">
                        <div className="feature-card">
                            <div className="feature-icon">🛡️</div>
                            <div className="feature-content">
                                <h3>Trust First</h3>
                                <p>Build a verifiable financial profile</p>
                            </div>
                        </div>

                        <div className="feature-card">
                            <div className="feature-icon">🤝</div>
                            <div className="feature-content">
                                <h3>Social Approvals</h3>
                                <p>Transactions require mutual consent</p>
                            </div>
                        </div>

                        <div className="feature-card">
                            <div className="feature-icon">📈</div>
                            <div className="feature-content">
                                <h3>Grow Your Score</h3>
                                <p>On-time payments build your Trust Score</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right Side - Sign In/Up Form */}
            <div className="signin-section">
                <div className="signin-container">
                    <div className="signin-card">
                        <div className="signin-header">
                            <h2 className="signin-title">
                                {isLogin ? 'Sign In' : (
                                    signupStep === 1 ? 'Create Account' :
                                        signupStep === 2 ? 'Verify Phone' : 'Link Aadhaar'
                                )}
                            </h2>
                            <p className="signin-subtitle">
                                {isLogin
                                    ? 'Welcome back! Please sign in to continue.'
                                    : (
                                        signupStep === 1 ? 'Join FinTrust to track informal loans.' :
                                            signupStep === 2 ? `We've sent an SMS to ${phone}` : 'Identity verification is mandatory for a trusted network.'
                                    )}
                            </p>
                        </div>

                        {/* Progress Indicators for Signup */}
                        {!isLogin && (
                            <div style={{ display: 'flex', gap: '8px', marginBottom: '24px', justifyContent: 'center' }}>
                                <div style={{ height: '4px', width: '30px', borderRadius: '4px', background: signupStep >= 1 ? '#2563EB' : '#E5E7EB' }}></div>
                                <div style={{ height: '4px', width: '30px', borderRadius: '4px', background: signupStep >= 2 ? '#2563EB' : '#E5E7EB' }}></div>
                                <div style={{ height: '4px', width: '30px', borderRadius: '4px', background: signupStep >= 3 ? '#2563EB' : '#E5E7EB' }}></div>
                            </div>
                        )}

                        {isLogin && (
                            <>
                                <button type="button" className="google-button" onClick={handleGoogleSignIn}>
                                    <svg className="google-icon" viewBox="0 0 24 24">
                                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                                    </svg>
                                    Continue with Google
                                </button>
                                <div className="divider">or</div>
                            </>
                        )}

                        <form onSubmit={handleSubmit}>
                            {error && (
                                <div style={{
                                    padding: '12px',
                                    marginBottom: '16px',
                                    backgroundColor: error.includes('sent') ? '#e7f3ff' : '#fee',
                                    border: `1px solid ${error.includes('sent') ? '#4a90e2' : '#fcc'}`,
                                    borderRadius: '8px',
                                    color: error.includes('sent') ? '#1a5490' : '#c33',
                                    fontSize: '14px'
                                }}>
                                    {error}
                                </div>
                            )}

                            {/* SIGNIN OR SIGNUP STEP 1 */}
                            {(isLogin || (!isLogin && signupStep === 1)) && (
                                <>
                                    {!isLogin && (
                                        <div className="form-group">
                                            <label htmlFor="name" className="form-label">Full Name</label>
                                            <input
                                                type="text"
                                                id="name"
                                                className="form-input"
                                                placeholder="Legal Name (Matches Aadhaar)"
                                                value={name}
                                                onChange={(e) => setName(e.target.value)}
                                                required={!isLogin}
                                            />
                                        </div>
                                    )}

                                    <div className="form-group">
                                        <label htmlFor="email" className="form-label">Email Address</label>
                                        <input
                                            type="email"
                                            id="email"
                                            className="form-input"
                                            placeholder="you@example.com"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            required
                                        />
                                    </div>

                                    {!isLogin && (
                                        <div className="form-group">
                                            <label htmlFor="phone" className="form-label">Phone Number</label>
                                            <input
                                                type="tel"
                                                id="phone"
                                                className="form-input"
                                                placeholder="+91 98765 43210"
                                                value={phone}
                                                onChange={(e) => setPhone(e.target.value)}
                                                required={!isLogin}
                                            />
                                        </div>
                                    )}

                                    {!isLogin && (
                                        <div className="form-group">
                                            <label htmlFor="photo" className="form-label">Passport Size Photo *</label>
                                            <input
                                                type="file"
                                                id="photo"
                                                accept="image/*"
                                                className="form-input"
                                                onChange={(e) => setPhotoFile(e.target.files[0])}
                                                required={!isLogin}
                                                style={{ padding: '8px', cursor: 'pointer', background: 'white' }}
                                            />
                                        </div>
                                    )}

                                    <div className="form-group">
                                        <label htmlFor="password" className="form-label">Password</label>
                                        <div className="password-wrapper">
                                            <input
                                                type={showPassword ? 'text' : 'password'}
                                                id="password"
                                                className="form-input"
                                                placeholder="Enter your password"
                                                value={password}
                                                onChange={(e) => setPassword(e.target.value)}
                                                required
                                            />
                                            <button
                                                type="button"
                                                className="password-toggle"
                                                onClick={() => setShowPassword(!showPassword)}
                                            >
                                                {showPassword ? '👁️' : '👁️‍🗨️'}
                                            </button>
                                        </div>
                                    </div>

                                    {isLogin && (
                                        <div className="form-row">
                                            <div className="checkbox-wrapper">
                                                <input
                                                    type="checkbox"
                                                    id="remember"
                                                    className="checkbox-input"
                                                    checked={rememberMe}
                                                    onChange={(e) => setRememberMe(e.target.checked)}
                                                />
                                                <label htmlFor="remember" className="checkbox-label">Remember me</label>
                                            </div>
                                            <a href="#forgot" className="forgot-link">Forgot password?</a>
                                        </div>
                                    )}
                                </>
                            )}

                            {/* SIGNUP STEP 2: MOCK OTP */}
                            {!isLogin && signupStep === 2 && (
                                <div className="form-group">
                                    <label htmlFor="otp" className="form-label">6-Digit OTP</label>
                                    <input
                                        type="text"
                                        id="otp"
                                        maxLength="6"
                                        className="form-input"
                                        placeholder="······"
                                        style={{ fontSize: '24px', letterSpacing: '8px', textAlign: 'center' }}
                                        value={otp}
                                        onChange={(e) => setOtp(e.target.value)}
                                        required
                                    />
                                    <p style={{ marginTop: '8px', fontSize: '12px', color: '#6B7280' }}>
                                        Check your SMS messages for the code. (Mock: 123456)
                                    </p>
                                </div>
                            )}

                            {/* SIGNUP STEP 3: MOCK AADHAAR */}
                            {!isLogin && signupStep === 3 && (
                                <div className="form-group">
                                    <label htmlFor="aadhaar" className="form-label">Aadhaar Number</label>
                                    <input
                                        type="text"
                                        id="aadhaar"
                                        maxLength="12"
                                        className="form-input"
                                        placeholder="XXXX XXXX XXXX"
                                        style={{ fontSize: '18px', letterSpacing: '4px', textAlign: 'center' }}
                                        value={aadhaar}
                                        onChange={(e) => setAadhaar(e.target.value)}
                                        required
                                    />
                                    <p style={{ marginTop: '8px', fontSize: '12px', color: '#6B7280' }}>
                                        FinTrust requires identity verification to build a trusted peer-to-peer network. (Mock: enter any 12 digits)
                                    </p>
                                </div>
                            )}

                            <button type="submit" className="signin-button" disabled={loading}>
                                {loading ? 'Processing...' : (
                                    isLogin ? 'Sign In' :
                                        (signupStep === 1 ? 'Send OTP' : signupStep === 2 ? 'Verify & Continue' : 'Create Account')
                                )}
                                <span>→</span>
                            </button>

                            {/* Back button for multi-step */}
                            {!isLogin && signupStep > 1 && (
                                <button
                                    type="button"
                                    style={{
                                        width: '100%', padding: '12px', marginTop: '12px',
                                        background: 'transparent', border: '1px solid #E5E7EB',
                                        borderRadius: '8px', color: '#4B5563', cursor: 'pointer', fontWeight: 500
                                    }}
                                    onClick={() => setSignupStep(signupStep - 1)}
                                >
                                    Back
                                </button>
                            )}
                        </form>

                        <div className="signup-link">
                            {isLogin ? "Don't have an account? " : "Already have an account? "}
                            <a href="#" onClick={(e) => {
                                e.preventDefault();
                                setIsLogin(!isLogin);
                                setSignupStep(1);
                                setError(null);
                            }}>
                                {isLogin ? 'Sign Up' : 'Sign In'}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginSignup;
